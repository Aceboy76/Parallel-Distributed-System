import json
import os
import time
from config import *
from common import count_log, load_committed_offsets, load_processed_ids, partition_end_offsets, read_events, save_committed_offsets, write_json

FAILURE_STATE = SESSION_DIR / 'state' / 'failure_audit'
FAILURE_OFFSETS = FAILURE_STATE / 'offsets.json'
FAILURE_IDS = FAILURE_STATE / 'processed_ids.txt'
FAILURE_DELIVERY = RESULTS_DIR / 'failure_delivery_attempts.jsonl'


def main() -> int:
    banner('FAILURE & RECOVERY — injected consumer crash and restart from committed offsets')
    total = count_log()
    if total == 0:
        raise SystemExit('Run producer.py first.')
    fail_after = int(os.getenv('CMA_FAIL_AFTER', FAIL_AFTER))
    if fail_after <= COMMIT_EVERY or fail_after > total:
        raise SystemExit(f'CMA_FAIL_AFTER must be between {COMMIT_EVERY + 1} and {total}.')

    FAILURE_STATE.mkdir(parents=True, exist_ok=True)
    FAILURE_OFFSETS.unlink(missing_ok=True); FAILURE_IDS.unlink(missing_ok=True); FAILURE_DELIVERY.unlink(missing_ok=True)
    committed = {p: 0 for p in range(PARTITIONS)}
    processed = set()
    attempted = 0

    with FAILURE_IDS.open('a', encoding='utf-8') as ledger, FAILURE_DELIVERY.open('a', encoding='utf-8') as delivery:
        # Phase 1: process batches; an injected crash interrupts a batch before its commit.
        batch_committed = {p: 0 for p in range(PARTITIONS)}
        batch_count = 0
        try:
            for event in read_events():
                attempted += 1
                eid = int(event['event_id']); delivery.write(json.dumps({'event_id': eid, 'attempt': attempted, 'phase': 'before-crash'}) + '\n')
                if eid not in processed:
                    ledger.write(f'{eid}\n'); processed.add(eid)
                part = int(event['partition'])
                batch_committed[part] = max(batch_committed[part], int(event['offset']) + 1)
                batch_count += 1
                if attempted == fail_after:
                    delivery.flush(); ledger.flush()
                    raise RuntimeError('INJECTED_FAILURE: simulated audit consumer process crash')
                if batch_count >= COMMIT_EVERY:
                    committed = dict(batch_committed)
                    ledger.flush(); delivery.flush()
                    save_committed_offsets(FAILURE_OFFSETS, committed, {'phase': 'crashed-run', 'attempted': attempted})
                    batch_count = 0
        except RuntimeError as exc:
            if not str(exc).startswith('INJECTED_FAILURE'):
                raise

        committed_before = load_committed_offsets(FAILURE_OFFSETS, PARTITIONS)
        committed_count = sum(committed_before.values())
        redelivery_attempts = fail_after - committed_count
        backlog_at_crash = total - committed_count

        recovery_start = time.perf_counter(); recovered_unique = 0; duplicates_prevented = 0; recovery_batch = 0
        for event in read_events():
            part = int(event['partition'])
            if int(event['offset']) < committed_before.get(part, 0):
                continue
            attempted += 1; recovery_batch += 1; eid = int(event['event_id'])
            delivery.write(json.dumps({'event_id': eid, 'attempt': attempted, 'phase': 'recovery'}) + '\n')
            if eid in processed:
                duplicates_prevented += 1
            else:
                ledger.write(f'{eid}\n'); processed.add(eid); recovered_unique += 1
            committed[part] = max(committed[part], int(event['offset']) + 1)
            if recovery_batch >= COMMIT_EVERY:
                ledger.flush(); delivery.flush(); save_committed_offsets(FAILURE_OFFSETS, committed, {'phase': 'recovered', 'attempted': attempted}); recovery_batch = 0
        ledger.flush(); delivery.flush(); save_committed_offsets(FAILURE_OFFSETS, committed, {'phase': 'recovered', 'attempted': attempted})

    recovery_seconds = time.perf_counter() - recovery_start
    total_delivery_records = sum(1 for _ in FAILURE_DELIVERY.open(encoding='utf-8'))
    end_offsets = partition_end_offsets()
    final_lag = sum(max(0, end_offsets.get(p, -1) + 1 - committed.get(p, 0)) for p in range(PARTITIONS))
    report = {
        'crash_after': fail_after,
        'committed_before_crash': committed_count,
        'committed_offsets_before_crash': {str(k): v for k, v in committed_before.items()},
        'backlog_at_crash': backlog_at_crash,
        'redelivered_count': redelivery_attempts,
        'redelivered_on_restart': redelivery_attempts,
        'recovered_unique_events': recovered_unique,
        'recovered_events': recovered_unique + redelivery_attempts,
        'duplicates_prevented_by_idempotency': duplicates_prevented,
        'catch_up_seconds': round(recovery_seconds, 6),
        'remaining_lag': final_lag, 'final_lag': final_lag,
        'total_delivery_attempts': total_delivery_records,
        'total_events_in_log': total,
        'events_lost': max(0, total - len(processed)),
        'producer_unaffected': True, 'other_consumers_unaffected': True,
        'injection': 'InjectedFailure exception after the configured delivery count; restart begins from persisted committed offsets.',
        'synchronous_design_cost': 'A synchronous producer/consumer chain would couple producer progress to the failed consumer and its recovery latency.'
    }
    write_json(OUT_FAILURE, report)
    print(f'crashed after handling {fail_after:,} events with only {committed_count:,} committed')
    print(f'backlog at crash       : {backlog_at_crash:,}')
    print(f'redelivered on restart : {redelivery_attempts:,}')
    print(f'catch-up time          : {recovery_seconds:.3f} s')
    print(f'final lag              : {final_lag:,}')
    print(f'events lost            : {report["events_lost"]:,}')
    print(f'duplicate effects prevented: {duplicates_prevented:,}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
