import subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAGES = ['log_self_test.py', 'producer.py', 'consumers.py', 'failure_recovery.py', 'replay.py', 'reconcile.py', 'session2_summary.py']

def main():
    log = ROOT / 'results' / 'session2_run.log'
    log.parent.mkdir(exist_ok=True)
    with log.open('w', encoding='utf-8') as out:
        for script in STAGES:
            out.write(f'\n===== {script} =====\n')
            out.flush()
            proc = subprocess.run([sys.executable, script], cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='utf-8')
            out.write(proc.stdout)
            print(proc.stdout, end='')
            if proc.returncode != 0:
                print(f'[{script}] FAILED with exit code {proc.returncode}')
                return proc.returncode
    print(f'End-to-end Session 2 run complete. Evidence log: {log}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
