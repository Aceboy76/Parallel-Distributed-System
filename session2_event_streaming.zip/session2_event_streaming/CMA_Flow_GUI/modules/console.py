from PyQt6.QtWidgets import QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QPlainTextEdit
from PyQt6.QtGui import QTextCursor
class ConsoleModule:
 def __init__(self,app):self.app=app
 def build(self,p):
  f=QVBoxLayout(p);f.setContentsMargins(22,16,22,12);r=QHBoxLayout();self.app.widgets.title(r,'Verbatim output of every stage');r.addStretch();b=QPushButton('Clear');b.clicked.connect(self.app.clear_console);r.addWidget(b);b=QPushButton('Stop process');b.setObjectName('danger');b.clicked.connect(self.app.stop_process);r.addWidget(b);f.addLayout(r);self.app.console=QPlainTextEdit();self.app.console.setReadOnly(True);self.app.console.setStyleSheet('QPlainTextEdit{background:#10213a;color:#e5edf7;border:1px solid #1b314e;font-family:Consolas;font-size:12px;padding:10px;}');f.addWidget(self.app.console)
 def write(self,text):self.app.console.moveCursor(QTextCursor.MoveOperation.End);self.app.console.insertPlainText(text);self.app.console.ensureCursorVisible()
