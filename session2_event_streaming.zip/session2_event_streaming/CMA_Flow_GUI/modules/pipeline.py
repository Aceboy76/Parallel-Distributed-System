from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView,QFrame
from .base import BaseModule
from .widgets import apply_table,align_row,card,NAVY,SUCCESS,SUCCESS_BG,DANGER,DANGER_BG,MUTED
STAGES=[('1. Log self-test','log_self_test.py'),('2. Produce','producer.py'),('3. Consume','consumers.py'),('4. Reconcile','reconcile.py'),('5. Failure & recovery','failure_recovery.py'),('6. Replay','replay.py')]
class PipelineModule(BaseModule):
    def build(self,parent):
        f=QVBoxLayout(parent);f.setContentsMargins(20,16,20,12);f.setSpacing(12)
        k=QHBoxLayout();k.setSpacing(12);f.addLayout(k);self.app.k_events=card(k,'—','events in the durable log',NAVY);self.app.k_groups=card(k,'—','consumer groups tracked',NAVY);self.app.k_lag=card(k,'—','total lag across all groups',SUCCESS);self.app.k_pass=card(k,'—','reconciliation vs Session 1',SUCCESS)
        row=QHBoxLayout();lab=QLabel('Run a stage');lab.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');row.addWidget(lab);row.addStretch()
        for text,fn in [('Log self-test',lambda:self.run_name('log_self_test.py')),('Produce',lambda:self.run_name('producer.py')),('Consume',lambda:self.run_name('consumers.py')),('Reconcile',lambda:self.run_name('reconcile.py')),('Failure & recovery',lambda:self.run_name('failure_recovery.py')),('Replay',lambda:self.run_name('replay.py'))]:b=QPushButton(text);b.clicked.connect(fn);row.addWidget(b)
        self.app.run_all_btn=QPushButton('Run everything');self.app.run_all_btn.setObjectName('primary');self.app.run_all_btn.clicked.connect(self.run_all);row.addWidget(self.app.run_all_btn)
        b=QPushButton('Refresh from results/');b.clicked.connect(self.app.refresh_all);row.addWidget(b);f.addLayout(row)
        self.app.stage_tree=QTableWidget(0,3);self.app.stage_tree.setHorizontalHeaderLabels(['Stage','Status','Headline result']);apply_table(self.app.stage_tree);h=self.app.stage_tree.horizontalHeader();h.setSectionResizeMode(0,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(1,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch);self.app.stage_tree.setColumnWidth(0,235);self.app.stage_tree.setColumnWidth(1,100);f.addWidget(self.app.stage_tree,1)
        note=QLabel('Every button runs the same Python stage used by the command line. The durable log is never recomputed for display; the tables below read the artifacts those stages actually returned. Stages depend on each other — Produce before Consume, and Consume before Reconcile.');note.setWordWrap(True);note.setStyleSheet('background:#eef4fb;color:#68809f;padding:11px;');f.addWidget(note)
        lab=QLabel('Artefacts in results/');lab.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');f.addWidget(lab)
        self.app.art_tree=QTableWidget(0,5);self.app.art_tree.setHorizontalHeaderLabels(['Artefact','Written by','Status','Size','Last written']);apply_table(self.app.art_tree);h=self.app.art_tree.horizontalHeader();h.setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);h.setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch);h.setSectionResizeMode(2,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(3,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(4,QHeaderView.ResizeMode.Fixed);self.app.art_tree.setColumnWidth(2,90);self.app.art_tree.setColumnWidth(3,100);self.app.art_tree.setColumnWidth(4,165);f.addWidget(self.app.art_tree,1)
    def run_name(self,script):self.app.start_pipeline([next((s for s in STAGES if s[1]==script),('Stage',script))])
    def run_all(self):self.app.start_pipeline(STAGES)
    def refresh(self):
        n=0
        if (self.app.results_dir/'durable_log_marker').exists(): pass
        log=self.app.log_path
        
        if log.exists():
            import json
            n=0
            for line in log.open('r',encoding='utf-8'):
                try:
                    if line.strip(): json.loads(line); n+=1
                except json.JSONDecodeError:
                    continue
        self.app.k_events.setText(f'{n:,}' if n else '—')
        lag=self.load_csv('consumer_lag.csv');total_lag=sum(int(float(r.get('final_lag',0))) for r in lag) if lag else 0;self.app.k_groups.setText(f'{len(lag):,}' if lag else '—');self.app.k_lag.setText(str(total_lag))
        rec=self.load_json('reconciliation_report.json');self.app.k_pass.setText('PASSED' if rec and rec.get('passed') else ('FAILED' if rec else '—'))
        self.app.stage_tree.setRowCount(0)
        for name,script in STAGES:
            p=self.app.results_dir
            mapping={'log_self_test.py':'selftest.ok','producer.py':'session2_throughput.csv','consumers.py':'consumer_lag.csv','reconcile.py':'reconciliation_report.json','failure_recovery.py':'failure_recovery.json','replay.py':'replay_report.json'}
            exists=(p/mapping[script]).exists();status='passed' if exists else 'not run';headline=self.headline(script)
            r=self.app.stage_tree.rowCount();self.app.stage_tree.insertRow(r)
            for c,v in enumerate((name,status,headline)):self.app.stage_tree.setItem(r,c,QTableWidgetItem(v));
            align_row(self.app.stage_tree,r,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignCenter,Qt.AlignmentFlag.AlignLeft])
            for c in range(3):self.app.stage_tree.item(r,c).setBackground(__import__('PyQt6.QtGui',fromlist=['QColor']).QColor(SUCCESS_BG if exists else '#ffffff'))
        self.app.art_tree.setRowCount(0)
        artifacts=[('event_schema.json','producer.py'),('selftest_report.json','log_self_test.py'),('session2_throughput.csv','producer.py'),('streamed_regional_revenue.csv','consumers.py — RevenueProjector'),('audit_log.jsonl','consumers.py — AuditWriter'),('high_value_alerts.csv','consumers.py — HighValueAlerter'),('consumer_lag.csv','consumers.py — lag report'),('consumer_offsets.csv','consumers.py — committed offsets'),('failure_recovery.json','failure_recovery.py'),('replay_report.json','replay.py'),('revenue_mechanism.csv','replay.py — derived mechanism'),('reconciliation_report.json','reconcile.py')]
        from datetime import datetime
        for fn,writer in artifacts:
            path=self.app.results_dir/fn;exists=path.exists();size='—';stamp='—'
            if exists:
                st=path.stat();size=f'{st.st_size/1024:.1f} KB' if st.st_size<1024*1024 else f'{st.st_size/1024/1024:.2f} MB';stamp=datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            r=self.app.art_tree.rowCount();self.app.art_tree.insertRow(r)
            for c,v in enumerate((fn,writer,'written' if exists else 'missing',size,stamp)):self.app.art_tree.setItem(r,c,QTableWidgetItem(v))
            align_row(self.app.art_tree,r,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignCenter,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignCenter])
    def headline(self,s):
        if s=='log_self_test.py':return 'All six guarantees hold — each backed by an assertion' if (self.app.results_dir/'selftest.ok').exists() else 'Run the six durability assertions'
        if s=='producer.py':
            r=self.load_csv('session2_throughput.csv');return f"{r[0]['events'] if r else '—'} events · {r[0]['events_per_second'] if r else '—'}/s · skew {r[0]['skew_ratio'] if r else '—'} : 1"
        if s=='consumers.py':
            r=self.load_csv('consumer_lag.csv');return f"{len(r)} groups · total lag {sum(int(x['final_lag']) for x in r) if r else 0} · producer changes needed: 0" if r else 'Run the three independent consumer groups'
        if s=='reconcile.py':
            r=self.load_json('reconciliation_report.json');return f"{'PASSED' if r and r.get('passed') else 'FAILED'} · {r.get('regions','—')} regions · Δcount {r.get('count_difference','—')} · Δmean {r.get('maximum_mean_difference','—')}" if r else 'Compare stream output with the Session 1 batch reference'
        if s=='failure_recovery.py':
            r=self.load_json('failure_recovery.json');return f"producer unaffected · backlog {r['backlog_at_crash']:,} retained · {r.get('redelivered_on_restart', r.get('redelivery_attempts',0)):,} redelivered" if r else 'Crash audit-writer and recover from the last committed offset'
        if s=='replay.py':
            r=self.load_json('replay_report.json');return f"late joiner saw {r['full_replay_events']:,} events · reprocessing deterministic" if r else 'Read history again from the durable log'
        return ''
