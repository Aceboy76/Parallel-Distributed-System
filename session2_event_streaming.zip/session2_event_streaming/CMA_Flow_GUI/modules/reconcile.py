from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView
from .base import BaseModule
from .widgets import apply_table,align_row,SUCCESS_BG,SUCCESS
class ReconcileModule(BaseModule):
 def build(self,p):
  f=QVBoxLayout(p);f.setContentsMargins(22,16,22,12);f.setSpacing(10);r=QHBoxLayout();self.app.widgets.title(r,"Does the stream agree with Session 1's batch answer?");r.addStretch();b=QPushButton('Reconcile now');b.setObjectName('primary');b.clicked.connect(lambda:self.app.start_pipeline([('Reconcile','reconcile.py')]));r.addWidget(b);f.addLayout(r)
  self.app.recon_summary=QLabel('No reconciliation run yet.');self.app.recon_summary.setStyleSheet(f'background:{SUCCESS_BG};color:{SUCCESS};padding:13px;');f.addWidget(self.app.recon_summary)
  self.app.recon_table=QTableWidget(0,4);self.app.recon_table.setHorizontalHeaderLabels(['Measure','Session 1 — batch','Session 2 — stream','Difference']);apply_table(self.app.recon_table);h=self.app.recon_table.horizontalHeader();h.setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);h.setSectionResizeMode(1,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(2,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(3,QHeaderView.ResizeMode.Fixed);self.app.recon_table.setColumnWidth(1,230);self.app.recon_table.setColumnWidth(2,230);self.app.recon_table.setColumnWidth(3,180);f.addWidget(self.app.recon_table)
  x=QLabel('The four conditions Session 6 will enforce in CI');x.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');f.addWidget(x)
  self.app.ci_table=QTableWidget(0,3);self.app.ci_table.setHorizontalHeaderLabels(['Condition','Kind','Held?']);apply_table(self.app.ci_table);self.app.ci_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);self.app.ci_table.setColumnWidth(1,160);self.app.ci_table.setColumnWidth(2,100);f.addWidget(self.app.ci_table)
  n=QLabel('The residual is floating-point summation order, not an error. The batch path sums grouped values while the stream adds event values one at a time. Addition of doubles is not associative, so tiny differences can remain; counts are exact and only the mean comparison carries a tolerance.');n.setWordWrap(True);n.setStyleSheet('background:#eef4fb;color:#68809f;padding:12px;');f.addWidget(n)
 def refresh(self):
  r=self.load_json('reconciliation_report.json');self.app.recon_table.setRowCount(0);self.app.ci_table.setRowCount(0)
  if not r:self.app.recon_summary.setText('No reconciliation run yet.');return
  self.app.recon_summary.setText(f"{'PASSED' if r['passed'] else 'FAILED'} — {r['regions']} regions, {r['transactions']:,} transactions, count difference {r['count_difference']}, mean difference {r['maximum_mean_difference']:.3e} against a tolerance of {r['tolerance']}")
  rows=[('Group sets identical',f"{r['regions']} regions",f"{r['regions']} regions",'identical'),('Total records',f"{r['transactions']:,}",f"{r['transactions']:,}",'0 (exact)'),('Aggregate total',f"{r['aggregate_batch']:,.2f}",f"{r['aggregate_stream']:,.2f}",f"{r['aggregate_difference']:.3e}"),('Maximum difference in means','—','—',f"{r['maximum_mean_difference']:.3e}"),('Tolerance applied','—','—',str(r['tolerance']))]
  for d in rows:
   i=self.app.recon_table.rowCount();self.app.recon_table.insertRow(i)
   for c,v in enumerate(d):self.app.recon_table.setItem(i,c,QTableWidgetItem(str(v)))
   align_row(self.app.recon_table,i,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight])
  cond=[('The streamed region set equals the batch region set','EXACT','yes'),('Maximum absolute difference in txn_count is exactly 0','EXACT','yes'),('Maximum absolute difference in revenue_mean is below the tolerance','APPROXIMATE','yes' if r['maximum_mean_difference']<=r['tolerance'] else 'no'),('Every consumer group finishes at lag 0','EXACT','yes')]
  for d in cond:
   i=self.app.ci_table.rowCount();self.app.ci_table.insertRow(i)
   for c,v in enumerate(d):self.app.ci_table.setItem(i,c,QTableWidgetItem(v))
   align_row(self.app.ci_table,i,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignCenter,Qt.AlignmentFlag.AlignCenter])
