from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView,QLineEdit
from .base import BaseModule
from .widgets import apply_table,align_row,SUCCESS_BG,SUCCESS,WARNING_BG,WARNING
class ReplayModule(BaseModule):
 def build(self,p):
  f=QVBoxLayout(p);f.setContentsMargins(22,16,22,12);f.setSpacing(10);r=QHBoxLayout();self.app.widgets.title(r,'What a durable log gives you for free');r.addStretch();r.addWidget(QLabel('partial replay from:'));self.app.replay_input=QLineEdit('2026-06-10T00:00:00Z');self.app.replay_input.setFixedWidth(215);r.addWidget(self.app.replay_input);b=QPushButton('Run all four demonstrations');b.setObjectName('primary');b.clicked.connect(lambda:self.app.start_pipeline([('Replay','replay.py')], {'CMA_REPLAY_FROM':self.app.replay_input.text()}));r.addWidget(b);f.addLayout(r)
  self.app.replay_summary=QLabel('No replay run yet.');self.app.replay_summary.setStyleSheet(f'background:{SUCCESS_BG};color:{SUCCESS};padding:13px;');f.addWidget(self.app.replay_summary)
  self.app.replay_table=QTableWidget(0,3);self.app.replay_table.setHorizontalHeaderLabels(['Demonstration','What it proves','Result']);apply_table(self.app.replay_table);h=self.app.replay_table.horizontalHeader();h.setSectionResizeMode(0,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch);h.setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch);self.app.replay_table.setColumnWidth(0,290);f.addWidget(self.app.replay_table)
  x=QLabel('Derived revenue mechanisms — computed by a late-joining consumer from the retained event history');x.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');f.addWidget(x)
  self.app.revenue_table=QTableWidget(0,4);self.app.revenue_table.setHorizontalHeaderLabels(['Mechanism','Dataset signal / rule','Events','Revenue proxy']);apply_table(self.app.revenue_table);h2=self.app.revenue_table.horizontalHeader();h2.setSectionResizeMode(0,QHeaderView.ResizeMode.Fixed);h2.setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch);h2.setSectionResizeMode(2,QHeaderView.ResizeMode.Fixed);h2.setSectionResizeMode(3,QHeaderView.ResizeMode.Fixed);self.app.revenue_table.setColumnWidth(0,300);self.app.revenue_table.setColumnWidth(2,110);self.app.revenue_table.setColumnWidth(3,140);f.addWidget(self.app.revenue_table,1)
 def refresh(self):
  r=self.load_json('replay_report.json');self.app.replay_table.setRowCount(0);self.app.revenue_table.setRowCount(0)
  if not r:self.app.replay_summary.setText('No replay run yet.');return
  self.app.replay_summary.setText(f"All four demonstrations ran · {r.get('full_replay_events', r.get('new_consumer_history_events', 0)):,} historical events · {r['full_replay_regions']} regions · replay revenue {r.get('revenue_total', r.get('metric_total', 0)):,.2f}")
  data=[('A new consumer reads all history','It did not exist when the events were produced; it read from offset 0',f"{r.get('full_replay_events', r.get('new_consumer_history_events', 0)):,} consumed"),('Rewind and reprocess','Two runs from offset 0 produce identical results',f"{r['full_replay_regions']} regions · identical = {r['deterministic']}"),('An offline consumer catches up','Nothing was asked of the producer; events were waiting in the log',f"backlog {r.get('full_replay_events', r.get('new_consumer_history_events', 0)):,} cleared deterministically"),(f"Partial replay from {r['partial_replay_from']}",'Offsets are positions, not timestamps, so this is a scan rather than a seek',f"{r['partial_replay_events']:,} of {r.get('full_replay_events', r.get('new_consumer_history_events', 0)):,} ({r['partial_replay_share']}%)")]
  for d in data:
   i=self.app.replay_table.rowCount();self.app.replay_table.insertRow(i)
   for c,v in enumerate(d):self.app.replay_table.setItem(i,c,QTableWidgetItem(str(v)))
   align_row(self.app.replay_table,i,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignLeft])
  # Aggregate the derived mechanism directly from the durable log.
  import collections, json
  agg=collections.defaultdict(lambda:[0,0.0])
  defs=r.get('mechanism_definitions', {})
  for line in self.app.log_path.open(encoding='utf-8'):
   line=line.strip()
   if not line: continue
   try: e=json.loads(line)
   except json.JSONDecodeError: continue
   k=e.get('mechanism','Unknown')
   agg[k][0]+=1
   agg[k][1]+=float(e.get('revenue',0.0))
  for mech,(n,rev) in sorted(agg.items()):
   i=self.app.revenue_table.rowCount();self.app.revenue_table.insertRow(i)
   data=(mech,defs.get(mech,'Derived from OULAD event signals'),f'{n:,}',f'{rev:,.2f}')
   for c,v in enumerate(data): self.app.revenue_table.setItem(i,c,QTableWidgetItem(v))
   align_row(self.app.revenue_table,i,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight])
