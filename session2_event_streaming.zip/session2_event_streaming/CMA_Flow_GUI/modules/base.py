import csv,json
class BaseModule:
    def __init__(self,app):self.app=app
    @property
    def results_dir(self):return self.app.results_dir
    @property
    def base_dir(self):return self.app.base_dir
    def load_json(self,name):
        p=self.results_dir/name
        try:return json.loads(p.read_text(encoding='utf-8')) if p.exists() else None
        except:return None
    def load_csv(self,name):
        p=self.results_dir/name
        try:
            with p.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
        except:return None
