from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QFrame,QLabel,QPushButton,QTableWidget,QSizePolicy,QHeaderView,QVBoxLayout
BG='#f7f9fc'; SURFACE='#ffffff'; NAVY='#223f73'; NAVY_2='#102a4d'; TEXT='#18304f'; MUTED='#6c7f98'; BORDER='#cbd6e3'; SUCCESS='#54833a'; SUCCESS_BG='#e4f1da'; WARNING='#c46a00'; WARNING_BG='#fde4d0'; DANGER='#b73b4a'; DANGER_BG='#f8e4e7'; BLUE='#3378b8'; BLUE_BG='#edf3fa'

def apply_table(t, compact=False):
    t.setShowGrid(False);t.setAlternatingRowColors(False);t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows);t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);t.verticalHeader().setVisible(False);t.setWordWrap(False)
    t.setStyleSheet(f'''QTableWidget{{background:white;color:{TEXT};border:1px solid #b8c2ce;font-size:13px;outline:none;}} QHeaderView::section{{background:{NAVY};color:white;border:0;padding:7px 8px;font-weight:700;font-size:13px;}} QTableWidget::item{{padding:{6 if compact else 8}px 7px;border:0;}} QTableWidget::item:selected{{background:#dbe8f7;color:{NAVY_2};}} QScrollBar:vertical{{width:12px;background:#eef2f6;}} QScrollBar::handle:vertical{{background:#aeb9c6;min-height:26px;}}''')
    t.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding)

def align_row(t,row,aligns=None):
    if aligns is None: aligns=[Qt.AlignmentFlag.AlignLeft]*t.columnCount()
    for c,a in enumerate(aligns):
        it=t.item(row,c)
        if it: it.setTextAlignment(a|Qt.AlignmentFlag.AlignVCenter)

def card(layout,value,subtitle,accent=NAVY):
    f=QFrame();f.setStyleSheet(f'QFrame{{background:{BLUE_BG};border:1px solid #c7d7ea;}}');v=QVBoxLayout(f);v.setContentsMargins(10,14,10,10);v.setSpacing(2)
    x=QLabel(value);x.setAlignment(Qt.AlignmentFlag.AlignCenter);x.setStyleSheet(f'color:{accent};font-family:Georgia;font-size:30px;font-weight:800;border:0;');v.addWidget(x)
    s=QLabel(subtitle);s.setAlignment(Qt.AlignmentFlag.AlignCenter);s.setStyleSheet(f'color:{MUTED};font-size:12px;border:0;');v.addWidget(s);layout.addWidget(f,1);return x

class WidgetFactory:
    def __init__(self,app):self.app=app
    def card(self,layout,value,subtitle,accent=NAVY):
        """Instance-compatible wrapper used by Session 2 modules."""
        return card(layout,value,subtitle,accent)
    def setup_style(self):
        self.app.setStyleSheet(f'''QWidget{{font-family:"Segoe UI";color:{TEXT};}} QMainWindow{{background:{BG};}} QPushButton{{background:#f4f7fb;color:#294a72;border:0;padding:9px 14px;font-size:13px;}} QPushButton:hover{{background:#e8eff8;}} QPushButton:disabled{{color:#9ba6b4;background:#eef1f4;}} QPushButton#primary{{background:{NAVY};color:white;font-weight:700;padding:10px 18px;}} QPushButton#danger{{background:{DANGER};color:white;font-weight:700;}} QTabWidget::pane{{border:1px solid #b5bec9;background:white;top:-1px;}} QTabBar::tab{{background:#f0f3f7;color:#58708e;padding:10px 16px;border:1px solid #bfc8d2;border-bottom:none;font-size:13px;}} QTabBar::tab:selected{{background:{NAVY};color:white;font-weight:700;}} QLineEdit{{border:1px solid #aeb8c5;padding:6px;}}''')
    @staticmethod
    def title(layout,text,sub=None):
        x=QLabel(text);x.setStyleSheet(f'font-family:Georgia;font-size:23px;font-weight:700;color:{TEXT};');layout.addWidget(x)
        if sub:
            y=QLabel(sub);y.setStyleSheet(f'font-size:12px;color:{MUTED};');layout.addWidget(y)
