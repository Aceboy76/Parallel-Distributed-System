from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPainter,QFont
from PyQt6.QtWidgets import QWidget
class BarChart(QWidget):
    def __init__(self,parent=None):super().__init__(parent);self.data=[];self.setMinimumHeight(230)
    def set_data(self,data):self.data=data;self.update()
    def paintEvent(self,e):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);w=self.width();h=self.height();p.fillRect(0,0,w,h,Qt.GlobalColor.white)
        if not self.data:return
        m=max(v for _,v in self.data) or 1;left=25;right=20;bottom=48;top=20;usable=w-left-right;gap=usable/max(len(self.data),1);barw=gap*.38
        p.setPen(Qt.GlobalColor.lightGray);p.drawLine(left,h-bottom,w-right,h-bottom)
        for i,(label,val) in enumerate(self.data):
            x=left+gap*i+(gap-barw)/2;bh=(h-top-bottom)*(val/m);y=h-bottom-bh
            p.setPen(Qt.GlobalColor.transparent);p.setBrush(Qt.GlobalColor.darkBlue if i==0 else Qt.GlobalColor.darkCyan);p.drawRect(int(x),int(y),int(barw),int(bh))
            p.setPen(Qt.GlobalColor.darkBlue);p.setFont(QFont('Segoe UI',9));p.drawText(int(x-15),int(y-7),int(barw+30),18,Qt.AlignmentFlag.AlignCenter,f'{val:,.0f}')
            p.setPen(Qt.GlobalColor.gray);p.drawText(int(x-25),h-bottom+7,int(barw+50),35,Qt.AlignmentFlag.AlignCenter|Qt.TextFlag.TextWordWrap,label)
