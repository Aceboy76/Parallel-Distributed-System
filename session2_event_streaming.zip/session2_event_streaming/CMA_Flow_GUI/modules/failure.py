from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView
from .base import BaseModule
from .widgets import apply_table,align_row,WARNING_BG,WARNING,DANGER_BG,DANGER,SUCCESS_BG,NAVY
class FailureModule(BaseModule):
 def build(self,p):
  f=QVBoxLayout(p);f.setContentsMargins(22,16,22,12);f.setSpacing(10);r=QHBoxLayout();self.app.widgets.title(r,'Crash the audit consumer on purpose');r.addStretch();self.app.fail_input=__import__('PyQt6.QtWidgets',fromlist=['QLineEdit']).QLineEdit('25000');self.app.fail_input.setFixedWidth(100);r.addWidget(self.app.fail_input);r.addWidget(QLabel('fail after N events:'));b=QPushButton('Inject failure, then recover');b.setObjectName('danger');b.clicked.connect(lambda:self.app.start_pipeline([('Failure & recovery','failure_recovery.py')], {'CMA_FAIL_AFTER':self.app.fail_input.text()}));r.addWidget(b);f.addLayout(r)
  self.app.failure_summary=QLabel('No failure simulation yet.');self.app.failure_summary.setStyleSheet(f'background:{WARNING_BG};color:{WARNING};padding:13px;');f.addWidget(self.app.failure_summary)
  x=QLabel('Blast radius — what else failed with it');x.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');f.addWidget(x);self.app.failure_table=QTableWidget(0,3);self.app.failure_table.setHorizontalHeaderLabels(['Component','Status','Evidence']);apply_table(self.app.failure_table);h=self.app.failure_table.horizontalHeader();h.setSectionResizeMode(0,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(1,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch);self.app.failure_table.setColumnWidth(0,220);self.app.failure_table.setColumnWidth(1,130);f.addWidget(self.app.failure_table)
  k=QHBoxLayout();self.app.f1=self.app.widgets.card(k,'—','handled before the crash',NAVY);self.app.f2=self.app.widgets.card(k,'—','backlog left in the log',NAVY);self.app.f3=self.app.widgets.card(k,'—','audit entries written',WARNING);self.app.f4=self.app.widgets.card(k,'—','redelivered on restart',DANGER);f.addLayout(k)
  self.app.failure_note=QLabel('The simulation uses the configured commit interval and the selected failure point against the actual durable log generated from the Session 1 dataset. The producer and other consumer groups retain independent progress.');self.app.failure_note.setWordWrap(True);self.app.failure_note.setStyleSheet('background:#eef4fb;color:#68809f;padding:12px;');f.addWidget(self.app.failure_note)
 def refresh(self):
  r=self.load_json('failure_recovery.json');self.app.failure_table.setRowCount(0)
  if not r:self.app.failure_summary.setText('No failure simulation yet.');return
  self.app.failure_summary.setText(f"Crashed after handling {r['crash_after']:,} events with only {r['committed_before_crash']:,} committed · backlog {r['backlog_at_crash']:,} · recovered {r.get('recovered_events', r.get('recovered_unique_events', 0)):,} · final lag {r.get('final_lag', r.get('remaining_lag', 0))}")
  self.app.f1.setText(f"{r['crash_after']:,}");self.app.f2.setText(f"{r['backlog_at_crash']:,}");self.app.f3.setText(f"{r['committed_before_crash']+r.get('recovered_events', r.get('recovered_unique_events', 0)):,}");self.app.f4.setText(f"{r.get('redelivered_on_restart', r.get('redelivery_attempts', 0)):,}")
  data=[('Producer','UNAFFECTED',f"{r['crash_after']+r['backlog_at_crash']:,} events already durable"),('revenue-projector','UNAFFECTED',f"processed {r['crash_after']+r['backlog_at_crash']:,}, lag 0"),('high-value-alerter','UNAFFECTED',f"processed {r['crash_after']+r['backlog_at_crash']:,}, lag 0"),('audit-writer','DOWN',f"lag {r['backlog_at_crash']:,}, events retained")]
  for d in data:
   i=self.app.failure_table.rowCount();self.app.failure_table.insertRow(i)
   for c,v in enumerate(d):self.app.failure_table.setItem(i,c,QTableWidgetItem(v))
   align_row(self.app.failure_table,i,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignCenter,Qt.AlignmentFlag.AlignLeft])
