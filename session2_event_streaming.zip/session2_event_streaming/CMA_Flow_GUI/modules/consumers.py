from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView
from .base import BaseModule
from .widgets import apply_table,align_row,SUCCESS_BG,NAVY
from .chart import BarChart
class ConsumersModule(BaseModule):
 def build(self,p):
  f=QVBoxLayout(p);f.setContentsMargins(22,16,22,12);f.setSpacing(10);r=QHBoxLayout();self.app.widgets.title(r,'Three groups, one topic, independent offsets');r.addStretch();b=QPushButton('Run all consumers');b.clicked.connect(lambda:self.app.start_pipeline([('Consume','consumers.py')]));r.addWidget(b);f.addLayout(r)
  self.app.consumer_summary=QLabel('No consumer run yet.');self.app.consumer_summary.setStyleSheet(f'background:{SUCCESS_BG};color:#54833a;padding:13px;');f.addWidget(self.app.consumer_summary)
  x=QLabel('Throughput of the last run');x.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');f.addWidget(x);self.app.consumer_chart=BarChart();f.addWidget(self.app.consumer_chart)
  self.app.consumer_table=QTableWidget(0,6);self.app.consumer_table.setHorizontalHeaderLabels(['Group','Processed','Seconds','Events/sec','Duplicates skipped','Final lag']);apply_table(self.app.consumer_table);h=self.app.consumer_table.horizontalHeader();h.setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);h.setSectionResizeMode(1,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(2,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(3,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(4,QHeaderView.ResizeMode.Fixed);h.setSectionResizeMode(5,QHeaderView.ResizeMode.Fixed)
  for c,w in [(1,120),(2,100),(3,120),(4,140),(5,100)]:self.app.consumer_table.setColumnWidth(c,w)
  f.addWidget(self.app.consumer_table)
  x=QLabel('Committed offsets, per group per partition  (results/consumer_lag.csv)');x.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');f.addWidget(x)
  self.app.offset_table=QTableWidget(0,4);self.app.offset_table.setHorizontalHeaderLabels(['Group','Partition','End offset','Committed / lag']);apply_table(self.app.offset_table);self.app.offset_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);f.addWidget(self.app.offset_table,1)
 def refresh(self):
  rows=self.load_csv('consumer_lag.csv');self.app.consumer_table.setRowCount(0);self.app.offset_table.setRowCount(0)
  if not rows:self.app.consumer_summary.setText('No consumer run yet.');return
  vals=[]
  for r in rows:
   i=self.app.consumer_table.rowCount();self.app.consumer_table.insertRow(i);data=(r['group'],f"{int(float(r['processed'])):,}",r['seconds'],f"{float(r['events_per_sec']):,.0f}",r['duplicates_skipped'],r['final_lag'])
   for c,v in enumerate(data):self.app.consumer_table.setItem(i,c,QTableWidgetItem(str(v)))
   align_row(self.app.consumer_table,i,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight]);vals.append((r['group'],float(r['events_per_sec'])))
  self.app.consumer_chart.set_data(vals);self.app.consumer_summary.setText(f"{len(rows)} groups finished · total lag {sum(int(float(r['final_lag'])) for r in rows)} · fastest {max(rows,key=lambda r:float(r['events_per_sec']))['group']} at {max(float(r['events_per_sec']) for r in rows):,.0f}/s · slowest {min(rows,key=lambda r:float(r['events_per_sec']))['group']} at {min(float(r['events_per_sec']) for r in rows):,.0f}/s")
  offset_rows=self.load_csv('consumer_offsets.csv') or []
  for r in offset_rows:
   i=self.app.offset_table.rowCount();self.app.offset_table.insertRow(i)
   data=(r['group'],r['partition'],f"{int(float(r['end_offset'])):,}",f"{int(float(r['committed_offset'])):,} / {int(float(r['lag']))}")
   for c,v in enumerate(data):self.app.offset_table.setItem(i,c,QTableWidgetItem(str(v)))
   align_row(self.app.offset_table,i,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight])
