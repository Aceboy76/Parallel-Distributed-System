from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView
from .base import BaseModule
from .widgets import apply_table,align_row,NAVY,SUCCESS_BG,SUCCESS
class DurableModule(BaseModule):
 def build(self,p):
  f=QVBoxLayout(p);f.setContentsMargins(22,16,22,12);f.setSpacing(10);row=QHBoxLayout();self.app.widgets.title(row,'The log and its partitions');row.addStretch();b=QPushButton('Produce (--reset)');b.clicked.connect(lambda:self.app.start_pipeline([('Produce','producer.py')]));row.addWidget(b);b=QPushButton('Run self-test');b.clicked.connect(lambda:self.app.start_pipeline([('Self-test','log_self_test.py')]));row.addWidget(b);f.addLayout(row)
  self.app.durable_summary=QLabel('No events produced yet.');self.app.durable_summary.setStyleSheet(f'background:{SUCCESS_BG};color:{SUCCESS};padding:13px;');f.addWidget(self.app.durable_summary)
  h=QLabel('Partition distribution');h.setStyleSheet(f'font-family:Georgia;font-size:18px;font-weight:700;');f.addWidget(h)
  self.app.durable_table=QTableWidget(0,4);self.app.durable_table.setHorizontalHeaderLabels(['Partition','Events','Share','Observation']);apply_table(self.app.durable_table);hd=self.app.durable_table.horizontalHeader();hd.setSectionResizeMode(0,QHeaderView.ResizeMode.Fixed);hd.setSectionResizeMode(1,QHeaderView.ResizeMode.Fixed);hd.setSectionResizeMode(2,QHeaderView.ResizeMode.Fixed);hd.setSectionResizeMode(3,QHeaderView.ResizeMode.Stretch);self.app.durable_table.setColumnWidth(0,160);self.app.durable_table.setColumnWidth(1,120);self.app.durable_table.setColumnWidth(2,120);f.addWidget(self.app.durable_table)
  self.app.guarantee_table=QTableWidget(0,2);self.app.guarantee_table.setHorizontalHeaderLabels(['Guarantee','Result']);apply_table(self.app.guarantee_table);self.app.guarantee_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);self.app.guarantee_table.setColumnWidth(1,130);f.addWidget(self.app.guarantee_table,1)
 def refresh(self):
  import json
  log=self.app.log_path;self.app.durable_table.setRowCount(0);self.app.guarantee_table.setRowCount(0)
  if not log.exists():self.app.durable_summary.setText('No events produced yet.');return
  counts={};n=0
  for line in log.open(encoding='utf-8'):
   if line.strip():
    e=json.loads(line);part=int(e['partition']);counts[part]=counts.get(part,0)+1;n+=1
  share=n/len(counts) if counts else 0;skew=max(counts.values())/min(counts.values()) if counts and min(counts.values()) else 0;self.app.durable_summary.setText(f'{n:,} events produced · {self.app.results_dir.joinpath("session2_throughput.csv").exists() and "throughput recorded" or ""} · log {log.stat().st_size/1024/1024:.2f} MB · skew {skew:.2f}:1')
  for part,cnt in counts.items():
   r=self.app.durable_table.rowCount();self.app.durable_table.insertRow(r);vals=(f'partition {part}',f'{cnt:,}',f'{cnt/n*100:.1f}%', 'above even share' if cnt>share else 'below even share');
   for c,v in enumerate(vals):self.app.durable_table.setItem(r,c,QTableWidgetItem(v));align_row(self.app.durable_table,r,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignRight,Qt.AlignmentFlag.AlignLeft])
  checks=['Stable key routing','Ordering within a partition','Non-destructive read','Consumer group isolation','Replay','Durability'];ok=(self.app.results_dir/'selftest.ok').exists()
  for x in checks:
   r=self.app.guarantee_table.rowCount();self.app.guarantee_table.insertRow(r);self.app.guarantee_table.setItem(r,0,QTableWidgetItem(x));self.app.guarantee_table.setItem(r,1,QTableWidgetItem('PASS' if ok else '—'));align_row(self.app.guarantee_table,r,[Qt.AlignmentFlag.AlignLeft,Qt.AlignmentFlag.AlignCenter])
