from __future__ import annotations
import os,sys,subprocess,threading,queue
from pathlib import Path
from PyQt6.QtCore import Qt,QTimer
from PyQt6.QtWidgets import QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTabWidget,QFrame,QMessageBox
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from modules.widgets import WidgetFactory,NAVY,NAVY_2,SUCCESS,SUCCESS_BG,DANGER,DANGER_BG,WARNING,WARNING_BG
from modules.pipeline import PipelineModule
from modules.durable import DurableModule
from modules.consumers import ConsumersModule
from modules.failure import FailureModule
from modules.replay import ReplayModule
from modules.reconcile import ReconcileModule
from modules.console import ConsoleModule
APP_TITLE='CMA-Flow — Session 2 Event Streaming Console'
class CMAFlowApp(QMainWindow):
 def __init__(self):
  super().__init__();self.setWindowTitle(APP_TITLE);self.resize(1500,930);self.setMinimumSize(1180,760);self.base_dir=ROOT;self.session1_dir=ROOT.parent/'session1_parallel_compute';self.results_dir=ROOT/'results';self.log_path=ROOT/'durable_log'/'transaction.recorded.jsonl';self.events=queue.Queue();self.proc=None;self.worker=None;self.running=False;self.widgets=WidgetFactory(self);self.widgets.setup_style();self.pipeline=PipelineModule(self);self.durable=DurableModule(self);self.consumers=ConsumersModule(self);self.failure=FailureModule(self);self.replay=ReplayModule(self);self.reconcile=ReconcileModule(self);self.console_module=ConsoleModule(self);self.build_header();self.build_tabs();self.build_footer();self.refresh_all();self.timer=QTimer(self);self.timer.timeout.connect(self.poll_events);self.timer.start(100)
 def build_header(self):
  h=QFrame();h.setFixedHeight(112);h.setStyleSheet(f'background:{NAVY};');l=QHBoxLayout(h);l.setContentsMargins(26,16,24,14);left=QVBoxLayout();t=QLabel('CMA-Flow — Session 2 Event Streaming Console');t.setStyleSheet('color:white;font-family:Georgia;font-size:25px;font-weight:700;');left.addWidget(t);s=QLabel('MIT 261 Parallel and Distributed Systems  ·  topic transaction.recorded  ·  keyed on region  ·  source: Session 1 Datasets/studentAssessment.csv + customers_dim.csv');s.setStyleSheet('color:#c7d7ee;font-size:12px;');left.addWidget(s);l.addLayout(left,1);self.status=QLabel('●  READY');self.status.setAlignment(Qt.AlignmentFlag.AlignCenter);self.status.setMinimumWidth(110);self.status.setStyleSheet('background:#edf2f7;color:#4a6078;padding:9px 12px;font-weight:700;');l.addWidget(self.status);b=QPushButton('Refresh');b.clicked.connect(self.refresh_all);l.addWidget(b);b=QPushButton('▶  Run everything');b.setObjectName('primary');b.clicked.connect(self.pipeline.run_all);l.addWidget(b);self.setMenuWidget(h)
 def build_tabs(self):
  shell=QWidget();lay=QVBoxLayout(shell);lay.setContentsMargins(12,10,12,5);self.tabs=QTabWidget();lay.addWidget(self.tabs);self.setCentralWidget(shell)
  for title,module in [('Pipeline',self.pipeline),('Durable log',self.durable),('Consumers & lag',self.consumers),('Failure & recovery',self.failure),('Replay',self.replay),('Reconciliation',self.reconcile),('Console',self.console_module)]:
   w=QWidget();self.tabs.addTab(w,title);module.build(w)
 def build_footer(self):
  f=QFrame();f.setFixedHeight(30);f.setStyleSheet(f'background:{NAVY_2};');l=QHBoxLayout(f);l.setContentsMargins(14,0,14,0);self.footer=QLabel('CMA-Flow ready');self.footer.setStyleSheet('color:#d7e4f5;font-size:11px;');l.addWidget(self.footer);l.addStretch();x=QLabel('Session 2  ·  Python / pandas / durable log simulation');x.setStyleSheet('color:#8fa7c5;font-size:11px;');l.addWidget(x);self.centralWidget().layout().addWidget(f)
 def set_status(self,text,kind='ready'):
  st={'ready':('#edf2f7','#4a6078'),'running':(WARNING_BG,WARNING),'passed':(SUCCESS_BG,SUCCESS),'failed':(DANGER_BG,DANGER)};bg,fg=st.get(kind,st['ready']);self.status.setText('●  '+text);self.status.setStyleSheet(f'background:{bg};color:{fg};padding:9px 12px;font-weight:700;')
 def refresh_all(self):
  self.pipeline.refresh();self.durable.refresh();self.consumers.refresh();self.failure.refresh();self.replay.refresh();self.reconcile.refresh();self.footer.setText('Results refreshed  ·  ready' if not self.running else self.footer.text())
 def start_pipeline(self,jobs,env_extra=None):
  if self.running:return
  self.running=True;self.set_status('RUNNING','running');self.run_all_btn.setEnabled(False);self.worker=threading.Thread(target=self.worker_run,args=(jobs,env_extra or {}),daemon=True);self.worker.start();self.tabs.setCurrentIndex(6)
 def worker_run(self,jobs,env_extra):
  for name,script in jobs:
   self.events.put(('start',name,script));path=self.base_dir/script
   if not path.exists():self.events.put(('fail',name,script,1,f'Missing {path}'));return
   env=os.environ.copy();env['PYTHONUNBUFFERED']='1';env.update(env_extra)
   try:
    self.proc=subprocess.Popen([sys.executable,script],cwd=str(self.base_dir),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1,env=env)
    self.events.put(('output','\n'+'='*72+'\nSTART  '+name+'\nCommand: '+sys.executable+' '+script+'\n'+'='*72+'\n'))
    if self.proc.stdout:
     for line in self.proc.stdout:self.events.put(('output',line))
    rc=self.proc.wait();self.events.put(('done',name,script,rc))
    if rc!=0:return
   except Exception as e:self.events.put(('fail',name,script,1,repr(e)));return
  self.events.put(('all_done',))
 def poll_events(self):
  try:
   while True:
    e=self.events.get_nowait();k=e[0]
    if k=='output':self.console_module.write(e[1])
    elif k=='start':self.footer.setText(f'Running  ·  {e[1]}')
    elif k=='done':
     self.console_module.write(f"\n[{e[2]}] {'FINISHED successfully' if e[3]==0 else 'FAILED'} (exit {e[3]}).\n");self.refresh_all()
     if e[3]!=0:self.running=False;self.run_all_btn.setEnabled(True);self.set_status('FAILED','failed');self.footer.setText(f'{e[1]}  ·  failed')
    elif k=='fail':self.console_module.write(f'\n[ERROR] {e[2]}: {e[4]}\n');self.running=False;self.run_all_btn.setEnabled(True);self.set_status('FAILED','failed')
    elif k=='all_done':self.running=False;self.run_all_btn.setEnabled(True);self.refresh_all();self.set_status('PASSED','passed');self.footer.setText('All stages completed successfully');
  except queue.Empty:pass
 def clear_console(self):self.console_module.app.console.clear();self.console_module.app.console.insertPlainText('Console cleared.\n')
 def stop_process(self):
  if self.proc and self.proc.poll() is None:
   try:self.proc.terminate();self.console_module.write('\n[STOP] Termination requested.\n')
   except Exception as e:self.console_module.write(f'\n[STOP ERROR] {e}\n')
 def closeEvent(self,e):
  self.stop_process();e.accept()
if __name__=='__main__':
 app=QApplication(sys.argv);w=CMAFlowApp();w.show();sys.exit(app.exec())
