# Session 2 GUI

Run from this folder's parent with:

```text
python CMA_Flow_GUI/cma_flow_gui.py
```

The UI is intentionally modeled after the supplied Session 2 reference screens: navy academic header, compact tab strip, pale-green result banners, fixed-width aligned tables, KPI cards, action buttons, durable-log partition view, consumer throughput chart, failure/recovery evidence, replay demonstrations, reconciliation matrix, and dark verbatim console.
