import hashlib
import json
import os
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, Iterator, Tuple

from config import COMMIT_EVERY, LOG_DIR, LOG_PATH


def ensure_dirs() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)


def write_json(path, data) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    os.replace(tmp, path)


def stable_partition(key: str, partitions: int) -> int:
    if partitions <= 0:
        raise ValueError('partitions must be positive')
    digest = hashlib.sha256(str(key).encode('utf-8')).digest()
    return int.from_bytes(digest[:8], 'big') % partitions


def iter_valid_events(start: int = 0, stop: int | None = None) -> Iterator[dict]:
    if not LOG_PATH.exists():
        raise FileNotFoundError(f'Missing durable log: {LOG_PATH}')
    with LOG_PATH.open('r', encoding='utf-8') as f:
        line_no = 0
        for raw in f:
            if line_no < start:
                line_no += 1
                continue
            if stop is not None and line_no >= stop:
                break
            line_no += 1
            raw = raw.strip()
            if not raw:
                continue
            try:
                yield json.loads(raw)
            except json.JSONDecodeError:
                # A torn final JSONL record should not make every consumer fail.
                continue


def read_events(start: int = 0, stop: int | None = None) -> Iterator[dict]:
    yield from iter_valid_events(start, stop)


def count_log() -> int:
    if not LOG_PATH.exists():
        return 0
    count = 0
    with LOG_PATH.open('r', encoding='utf-8') as f:
        for raw in f:
            if not raw.strip():
                continue
            try:
                json.loads(raw)
            except json.JSONDecodeError:
                continue
            count += 1
    return count


def log_partition_counts() -> Dict[int, int]:
    counts: Dict[int, int] = defaultdict(int)
    for e in read_events():
        counts[int(e['partition'])] += 1
    return dict(counts)


def load_committed_offsets(path: Path, partitions: int) -> Dict[int, int]:
    if not path.exists():
        return {p: 0 for p in range(partitions)}
    data = json.loads(path.read_text(encoding='utf-8'))
    raw = data.get('committed_offsets', data)
    return {p: int(raw.get(str(p), raw.get(p, 0))) for p in range(partitions)}


def save_committed_offsets(path: Path, offsets: Dict[int, int], meta: dict | None = None) -> None:
    payload = {'committed_offsets': {str(k): int(v) for k, v in sorted(offsets.items())}}
    if meta:
        payload.update(meta)
    write_json(path, payload)


def load_processed_ids(path: Path) -> set[int]:
    if not path.exists():
        return set()
    result: set[int] = set()
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    result.add(int(line))
                except ValueError:
                    continue
    return result


def append_processed_id(path: Path, event_id: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(f'{int(event_id)}\n')
        f.flush()
        os.fsync(f.fileno())


def partition_end_offsets() -> Dict[int, int]:
    ends: Dict[int, int] = defaultdict(lambda: -1)
    for e in read_events():
        p = int(e['partition'])
        ends[p] = max(ends[p], int(e['offset']))
    return dict(ends)


def now() -> float:
    return time.perf_counter()


def batches(iterable: Iterable[dict], size: int = COMMIT_EVERY) -> Iterator[list[dict]]:
    batch: list[dict] = []
    for item in iterable:
        batch.append(item)
        if len(batch) >= size:
            yield batch
            batch = []
    if batch:
        yield batch


def grouped_region_aggregate(events: Iterable[dict]) -> dict[str, list[float]]:
    agg: dict[str, list[float]] = defaultdict(lambda: [0, 0.0])
    for e in events:
        agg[e['region']][0] += 1
        agg[e['region']][1] += float(e['revenue'])
    return dict(agg)
