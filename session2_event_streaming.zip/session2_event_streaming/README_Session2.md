# CMA-Flow — Session 2: Event Streaming and Messaging Backbones

Session 2 replays the **Session 1 OULAD assessment event dataset** as a file-backed event stream and proves that the streamed regional result reconciles with the Session 1 batch baseline.

## Session 1 handover

Session 2 uses the existing Session 1 prepared files directly:

- `../session1_parallel_compute/Datasets/studentAssessment.csv` — 173,912 assessment events
- `../session1_parallel_compute/Datasets/customers_dim.csv` — 28,785 unique students with `region`
- `../session1_parallel_compute/results/baseline_result.csv` — the Session 1 regional batch reference

The inherited partition key is `region`. The inherited event-time field is `studentAssessment.date_submitted`, represented in the event stream as UTC `timestamp` relative to the documented module-start date.

## Architecture

The backbone is a **file-backed JSONL durable log** at `durable_log/transaction.recorded.jsonl`. It is a local simulation of a partitioned topic, not a replicated broker. It provides replayable records and consumer-local committed offsets, but it does not provide broker replication or machine-failure failover.

An architecture diagram using actual repository names is stored at:

```text
architecture/architecture-session2.png
```

## Event schema

Each published record contains:

- `event_id`
- `event_type = assessment.submitted`
- `schema_version = 1.0`
- `topic = transaction.recorded`
- `partition`
- `offset`
- `partition_key = region`
- `id_student`
- `id_assessment`
- `region`
- `score`
- `revenue` (score-based monetization proxy used only for reconciliation)
- `revenue_is_proxy`
- `mechanism` (derived CMA-Flow business category)
- `mechanism_basis`
- `assessment_type`
- `timestamp`

`region` is enriched from `customers_dim.csv`, and `date_unregistration` is enriched from `entitlements_dim.csv`; both joins use pandas `many_to_one` validation and the combined enrichment is protected by an explicit row-count assertion: 173,912 rows before and after. The revenue mechanism is derived from OULAD signals (score and unregistration status); OULAD does not contain a native revenue-mechanism field. The numeric `revenue` field is a score-based proxy so Session 2 can reconcile exactly with Session 1's score totals.

### Derived revenue mechanisms

The GUI uses these project-level mechanisms, derived only from fields present in the OULAD-based Session 1 data:

- **Revenue secured / continuation revenue** — score >= 40 and no recorded unregistration at the event time.
- **Revenue secured + upsell next module** — score >= 80 and no recorded unregistration at the event time.
- **Resit / repeat revenue** — score below 40 and no recorded unregistration at the event time.
- **Early intervention / outcome pending** — the assessment has no score.
- **Revenue at risk / lost** — the event occurs on or after the student's recorded `date_unregistration`.

These are business classifications for the CMA-Flow monetization model, not native OULAD revenue labels. The numeric `revenue`/score value remains unchanged so the regional stream can still reconcile against Session 1.

## Producer

`producer.py`:

1. loads the full Session 1 `studentAssessment.csv`;
2. joins `customers_dim.csv` on `id_student`;
3. asserts that the join does not change row count;
4. sorts by `date_submitted`, `id_student`, `id_assessment`, and source row using a stable sort;
5. hashes `region` with SHA-256 and maps it to four partitions;
6. assigns monotonic offsets independently within each partition; and
7. writes the ordered events to the durable JSONL log.

The routing function is shared with the self-test so the test verifies the algorithm actually used by the producer.

## Consumer groups and delivery semantics

Three independent groups are implemented without producer changes:

- `revenue-projector` → `results/streamed_regional_revenue.csv`
- `audit-writer` → `results/audit_log.jsonl`
- `high-value-alerter` → `results/high_value_alerts.csv`

Each group stores committed offsets in `state/<group>.offsets.json` and a processed-event ledger in `state/<group>.processed_ids.txt`. `results/consumer_idempotency_test.json` explicitly re-presents the most recent committed batch and proves the event-id ledger would suppress those duplicate side effects.

The implementation is **at-least-once**: offsets are committed after processing, every 5,000 deliveries. A crash after a side effect but before the offset commit may cause the same event to be delivered again. The consumer's event-id ledger makes the side effect idempotent and records the duplicate as `duplicates_skipped` rather than applying it twice.

A second run begins from the persisted committed offsets and therefore processes no new events when the group is already caught up. A brand-new group starts from offset zero and can read the entire history.

## Failure and recovery

`failure_recovery.py` injects an `InjectedFailure` after `FAIL_AFTER` deliveries, records the last persisted commit, and then restarts from those committed offsets. The recovery report records the backlog, redelivery count, catch-up time, final lag, duplicates prevented, and whether the producer/other consumers were unaffected.

## Replay

`replay.py` demonstrates:

1. a new consumer reading the full history;
2. rewind/reprocessing with deterministic aggregate hashes;
3. offline catch-up from the durable log without producer interaction; and
4. partial replay from `REPLAY_FROM` by scanning event timestamps.

## Reconciliation

`reconcile.py` compares `results/streamed_regional_revenue.csv` against Session 1's `results/baseline_result.csv`.

The CI pass condition is:

```text
same region set
AND max txn_count difference == 0
AND max score_total/revenue_total difference == 0
AND max score_mean difference <= 1e-6
```

## Run order

From this folder:

```bash
python producer.py
python log_self_test.py
python consumers.py
python failure_recovery.py
python replay.py
python reconcile.py
python session2_summary.py
python CMA_Flow_GUI/cma_flow_gui.py
```

For a clean production run, `producer.py` resets the durable log, consumer state, and Session 2 result artifacts. For a single reproducible command-line evidence run, use `python run_session2.py`; it executes the stages in order and writes `results/session2_run.log`.

## Evidence files

- `results/event_schema.json`
- `results/selftest_report.json`
- `results/session2_throughput.csv`
- `results/partition_distribution.csv`
- `results/session2_run.log`
- `results/consumer_lag.csv`
- `results/consumer_offsets.csv`
- `results/consumer_idempotency_test.json`
- `results/streamed_regional_revenue.csv`
- `results/audit_log.jsonl`
- `results/high_value_alerts.csv`
- `results/failure_recovery.json`
- `results/replay_report.json`
- `results/revenue_mechanism.csv`
- `results/reconciliation_report.json`
- `results/session2_summary.json`
- `architecture/architecture-session2.png`
