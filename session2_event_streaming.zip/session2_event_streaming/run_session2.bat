@echo off
cd /d "%~dp0"
python CMA_Flow_GUI\cma_flow_gui.py
