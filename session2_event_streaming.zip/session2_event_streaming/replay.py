import hashlib
import json
from collections import defaultdict
from datetime import datetime

from config import *
from common import count_log, read_events, write_json


def aggregate_stream():
    agg = defaultdict(lambda: [0, 0.0])
    mechanism = defaultdict(lambda: [0, 0.0])
    count = 0
    first_ts = last_ts = None
    for e in read_events():
        count += 1
        dt = datetime.fromisoformat(e['timestamp'].replace('Z', '+00:00'))
        if first_ts is None: first_ts = dt
        last_ts = dt
        if e.get('score') is not None:
            agg[e['region']][0] += 1
        agg[e['region']][1] += float(e['revenue'])
        key = e['mechanism']
        mechanism[key][0] += 1
        mechanism[key][1] += float(e['revenue'])
    canonical = {k: [v[0], round(v[1], 12)] for k, v in sorted(agg.items())}
    mech = {k: {'events': v[0], 'revenue': round(v[1], 2)} for k, v in sorted(mechanism.items())}
    mechanism_csv = RESULTS_DIR / 'revenue_mechanism.csv'
    with mechanism_csv.open('w', newline='', encoding='utf-8') as f:
        import csv
        w = csv.writer(f)
        w.writerow(['mechanism', 'events', 'revenue_proxy'])
        for k, v in sorted(mech.items()):
            w.writerow([k, v['events'], f"{v['revenue']:.2f}"])
    return count, canonical, mech, first_ts, last_ts


def digest(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode('utf-8')).hexdigest()


def main() -> int:
    banner('REPLAY — full history, rewind, offline catch-up, and partial replay')
    total = count_log()
    if total == 0:
        raise SystemExit('Run producer.py first.')

    full_count, first, mech, first_ts, last_ts = aggregate_stream()
    _, second, _, _, _ = aggregate_stream()
    deterministic = digest(first) == digest(second)
    offline_catchup = sum(1 for _ in read_events())
    threshold = datetime.fromisoformat(REPLAY_FROM.replace('Z', '+00:00'))
    partial_count = 0
    for e in read_events():
        if datetime.fromisoformat(e['timestamp'].replace('Z', '+00:00')) >= threshold:
            partial_count += 1

    metric_total = round(sum(v['revenue'] for v in mech.values()), 2)
    report = {
        'new_consumer_history_events': full_count,
        'full_replay_events': full_count,
        'rewind_first_hash': digest(first),
        'rewind_second_hash': digest(second),
        'deterministic': deterministic,
        'offline_consumer_catchup_events': offline_catchup,
        'partial_replay_from': REPLAY_FROM,
        'partial_replay_events': partial_count,
        'partial_replay_share': round(partial_count / full_count * 100, 2),
        'full_replay_regions': len(first),
        'event_time_range': [first_ts.isoformat() if first_ts else None, last_ts.isoformat() if last_ts else None],
        'metric': 'revenue_proxy_total_by_derived_mechanism',
        'metric_total': metric_total,
        'revenue_total': metric_total,
        'mechanism_breakdown': mech,
        'mechanism_definitions': {
            'Revenue secured / continuation revenue': 'score >= 40 and below the upsell threshold, with no recorded unregistration at the event time',
            'Revenue secured + upsell next module': 'score >= 80 and no recorded unregistration at the event time',
            'Resit / repeat revenue': 'score below 40 and no recorded unregistration at the event time',
            'Early intervention / outcome pending': 'score is missing',
            'Revenue at risk / lost': "event occurs on/after the student's recorded date_unregistration",
        },
        'monetization_note': 'Mechanisms are derived from OULAD fields; revenue is the score-based reconciliation proxy.',
        'why_not_producer': 'The producer publishes normalized assessment events. The late consumer derives CMA-Flow revenue mechanisms from retained OULAD history using score and unregistration signals.',
    }
    write_json(OUT_REPLAY, report)
    print(f'new consumer saw        : {full_count:,} events')
    print(f'rewind deterministic     : {deterministic}')
    print(f'offline catch-up         : {offline_catchup:,} events')
    print(f'partial replay           : {partial_count:,} of {full_count:,} ({report["partial_replay_share"]}%)')
    print(f'late-joiner metric total : {metric_total:,.2f}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
