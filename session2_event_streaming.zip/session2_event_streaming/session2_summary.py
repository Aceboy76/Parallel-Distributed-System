import json
from pathlib import Path

from config import *
from common import count_log, log_partition_counts, write_json


def main():
    data = {
        'events': count_log(),
        'partitions': PARTITIONS,
        'partition_counts': log_partition_counts(),
        'groups': list(GROUPS),
    }
    for key, path in [
        ('producer', OUT_PRODUCER), ('lag', OUT_LAG), ('idempotency', RESULTS_DIR / 'consumer_idempotency_test.json'), ('failure', OUT_FAILURE),
        ('replay', OUT_REPLAY), ('reconcile', OUT_RECON), ('selftest', RESULTS_DIR / 'selftest_report.json'),
    ]:
        if path.exists():
            if path.suffix == '.json':
                data[key] = json.loads(path.read_text(encoding='utf-8'))
            else:
                data[key] = path.read_text(encoding='utf-8').strip()
    write_json(OUT_SUMMARY, data)


if __name__ == '__main__':
    main()
