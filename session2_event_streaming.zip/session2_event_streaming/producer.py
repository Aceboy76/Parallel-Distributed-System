import csv
import json
import time
from datetime import datetime, timedelta, timezone

import pandas as pd

from config import *
from common import stable_partition, write_json


def banner(title: str):
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def derive_revenue_mechanism(score, date_submitted, date_unregistration):
    """Derive a project-level monetization mechanism from OULAD outcome signals.

    OULAD does not contain a native revenue/mechanism field. The categories below
    are explicit CMA-Flow business rules built from real dataset fields.
    """
    if pd.notna(date_unregistration) and int(date_submitted) >= int(date_unregistration):
        return 'Revenue at risk / lost'
    if pd.isna(score):
        return 'Early intervention / outcome pending'
    score = float(score)
    if score < PASS_SCORE:
        return 'Resit / repeat revenue'
    if score >= UPSELL_SCORE:
        return 'Revenue secured + upsell next module'
    return 'Revenue secured / continuation revenue'


def main() -> int:
    banner('PRODUCER — event-time ordered append to durable log')
    if not ASSESSMENTS.exists() or not CUSTOMERS.exists() or not ENTITLEMENTS.exists():
        raise SystemExit('Session 1 source files are missing.')

    df = pd.read_csv(ASSESSMENTS, nrows=EVENT_LIMIT) if EVENT_LIMIT else pd.read_csv(ASSESSMENTS)
    customers = pd.read_csv(CUSTOMERS, usecols=['id_student', 'region'])
    entitlements = pd.read_csv(ENTITLEMENTS, usecols=['id_student', 'date_unregistration'])
    before = len(df)
    df = df.merge(customers, on='id_student', how='left', validate='many_to_one')
    df = df.merge(entitlements, on='id_student', how='left', validate='many_to_one')
    after = len(df)
    assert after == before, f'Enrichment row-count changed: {before} -> {after}'
    assert not df['region'].isna().any(), 'Region enrichment produced null routing keys'

    # Session 1 established date_submitted as the event-time field. Sort before publishing.
    df['_source_row'] = range(len(df))
    df = df.sort_values(['date_submitted', 'id_student', 'id_assessment', '_source_row'], kind='mergesort').reset_index(drop=True)

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    for path in [OUT_PRODUCER, OUT_REVENUE, OUT_AUDIT, OUT_ALERTS, OUT_LAG, OUT_FAILURE, OUT_REPLAY, OUT_RECON, OUT_SUMMARY,
                 RESULTS_DIR / 'consumer_offsets.csv', RESULTS_DIR / 'consumer_idempotency_test.json', RESULTS_DIR / 'failure_delivery_attempts.jsonl',
                 RESULTS_DIR / 'selftest_report.json', RESULTS_DIR / 'event_schema.json', RESULTS_DIR / 'partition_distribution.csv']:
        if path.exists():
            path.unlink()
    state_dir = SESSION_DIR / 'state'
    state_dir.mkdir(parents=True, exist_ok=True)
    for path in state_dir.glob('*'):
        if path.is_file():
            path.unlink()
    LOG_PATH.unlink(missing_ok=True)

    partitions = [0] * PARTITIONS
    base = datetime(2026, 6, 1, tzinfo=timezone.utc)
    event_timestamps = []
    t0 = time.perf_counter()
    with LOG_PATH.open('w', encoding='utf-8') as out:
        for event_id, row in df.iterrows():
            region = str(row['region'])
            part = stable_partition(region, PARTITIONS)
            offset = partitions[part]
            partitions[part] += 1
            ts = base + timedelta(days=int(row['date_submitted']))
            event_timestamps.append(ts)
            score = None if pd.isna(row['score']) else float(row['score'])
            revenue = 0.0 if score is None else score
            mechanism = derive_revenue_mechanism(score, row['date_submitted'], row['date_unregistration'])
            event = {
                'event_id': int(event_id),
                'event_type': EVENT_TYPE,
                'schema_version': SCHEMA_VERSION,
                'topic': TOPIC,
                'partition': part,
                'offset': offset,
                'partition_key': region,
                'id_student': int(row['id_student']),
                'id_assessment': int(row['id_assessment']),
                'assessment_type': None if 'assessment_type' not in row or pd.isna(row['assessment_type']) else str(row['assessment_type']),
                'region': region,
                'score': score,
                # The OULAD dataset has no monetary field; score is retained as a proxy
                # so the stream can reconcile exactly with Session 1's score totals.
                'revenue': revenue,
                'revenue_is_proxy': True,
                'mechanism': mechanism,
                'mechanism_basis': 'derived from score and date_unregistration; revenue is a score proxy, not native OULAD revenue',
                'timestamp': ts.isoformat().replace('+00:00', 'Z'),
            }
            out.write(json.dumps(event, separators=(',', ':')) + '\n')

    elapsed = time.perf_counter() - t0
    total = len(df)
    rate = total / elapsed if elapsed else 0
    skew = max(partitions) / min(partitions) if min(partitions) else 0

    with OUT_PRODUCER.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['events', 'seconds', 'events_per_second', 'log_size_mb', 'skew_ratio'])
        w.writerow([total, f'{elapsed:.6f}', f'{rate:.0f}', f'{LOG_PATH.stat().st_size/1024/1024:.2f}', f'{skew:.2f}'])
    with (RESULTS_DIR / 'partition_distribution.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['partition', 'events', 'share_of_total', 'observation'])
        even = total / PARTITIONS if total else 0
        for part, cnt in enumerate(partitions):
            w.writerow([part, cnt, f'{cnt/total*100:.4f}' if total else '0', 'above even share' if cnt > even else 'below even share'])

    schema = {
        'topic': TOPIC,
        'event_type': EVENT_TYPE,
        'schema_version': SCHEMA_VERSION,
        'partitions': PARTITIONS,
        'partition_key': PARTITION_KEY,
        'event_time': 'timestamp (derived from studentAssessment.date_submitted)',
        'payload': {
            'event_id': 'int', 'event_type': 'string', 'schema_version': 'string',
            'id_student': 'int', 'id_assessment': 'int', 'assessment_type': 'string|null',
            'region': 'string', 'score': 'float|null', 'revenue': 'float', 'revenue_is_proxy': 'bool',
            'mechanism': 'string', 'mechanism_basis': 'string', 'timestamp': 'ISO-8601 UTC string'
        },
        'enrichment': {
            'fields_added': ['region', 'date_unregistration'],
            'sources': ['customers_dim.csv', 'entitlements_dim.csv'],
            'join_keys': ['id_student', 'id_student'],
            'rows_before': before, 'rows_after': after,
            'row_count_assertion': 'assert after == before'
        },
        'ordering': 'date_submitted ascending, then id_student, id_assessment, source row',
        'monetization_note': 'OULAD has no native revenue field. revenue equals score as a documented reconciliation proxy; mechanism is a derived CMA-Flow business classification.'
    }
    write_json(RESULTS_DIR / 'event_schema.json', schema)

    print(f'rows before enrichment : {before:,}')
    print(f'rows after enrichment  : {after:,}')
    print(f'produced               : {total:,} events in {elapsed:.3f} s')
    print(f'event-time range       : {min(event_timestamps).isoformat()} -> {max(event_timestamps).isoformat()}')
    print(f'distinct regions       : {df[PARTITION_KEY].nunique():,}')
    print(f'throughput             : {rate:,.0f} events/second')
    print(f'log size               : {LOG_PATH.stat().st_size/1024/1024:.2f} MB')
    print(f'partition counts       : {partitions}')
    print(f'partition skew         : {skew:.2f} : 1')
    from log_self_test import main as run_self_test
    if run_self_test() != 0:
        raise SystemExit('Durable-log self-test failed after production.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
