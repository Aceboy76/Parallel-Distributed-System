from pathlib import Path
import sys, os

SESSION_DIR = Path(__file__).resolve().parent
SESSION1_DIR = SESSION_DIR.parent / 'session1_parallel_compute'
DATA_DIR = SESSION1_DIR / 'Datasets'
RESULTS_DIR = SESSION_DIR / 'results'
LOG_DIR = SESSION_DIR / 'durable_log'
LOG_PATH = LOG_DIR / 'transaction.recorded.jsonl'
RESULTS_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

EVENT_LIMIT = None  # Use the complete Session 1 assessment dataset; None means all rows.
PARTITIONS = 4
TOPIC = 'transaction.recorded'
PARTITION_KEY = 'region'
COMMIT_EVERY = 5000
FAIL_AFTER = 25000
REPLAY_FROM = '2026-06-10T00:00:00Z'
EVENT_TYPE = 'assessment.submitted'
SCHEMA_VERSION = '1.0'
TOLERANCE = 1e-6

ASSESSMENTS = DATA_DIR / 'studentAssessment.csv'
CUSTOMERS = DATA_DIR / 'customers_dim.csv'
ENTITLEMENTS = DATA_DIR / 'entitlements_dim.csv'

# Project-level monetization rules derived from OULAD fields. These are NOT native OULAD revenue fields.
PASS_SCORE = 40.0
UPSELL_SCORE = 80.0

OUT_PRODUCER = RESULTS_DIR / 'session2_throughput.csv'
OUT_REVENUE = RESULTS_DIR / 'streamed_regional_revenue.csv'
OUT_AUDIT = RESULTS_DIR / 'audit_log.jsonl'
OUT_ALERTS = RESULTS_DIR / 'high_value_alerts.csv'
OUT_LAG = RESULTS_DIR / 'consumer_lag.csv'
OUT_FAILURE = RESULTS_DIR / 'failure_recovery.json'
OUT_REPLAY = RESULTS_DIR / 'replay_report.json'
OUT_RECON = RESULTS_DIR / 'reconciliation_report.json'
OUT_SUMMARY = RESULTS_DIR / 'session2_summary.json'

GROUPS = ('revenue-projector','audit-writer','high-value-alerter')

def banner(title: str):
    print('\n' + '=' * 72)
    print(title)
    print('=' * 72)
