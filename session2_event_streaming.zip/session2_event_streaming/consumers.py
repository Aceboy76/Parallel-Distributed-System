import csv
import json
import time
from collections import defaultdict

from config import *
from common import count_log, load_committed_offsets, load_processed_ids, partition_end_offsets, read_events, save_committed_offsets, write_json

STATE_DIR = SESSION_DIR / 'state'


def _paths(group: str):
    safe = group.replace('-', '_')
    return STATE_DIR / f'{safe}.offsets.json', STATE_DIR / f'{safe}.processed_ids.txt'


def _eligible_events(group: str):
    offset_path, _ = _paths(group)
    committed = load_committed_offsets(offset_path, PARTITIONS)
    for event in read_events():
        if int(event['offset']) < committed.get(int(event['partition']), 0):
            continue
        yield event


def _write_commit(group: str, offsets: dict[int, int], total_processed: int):
    offset_path, _ = _paths(group)
    save_committed_offsets(offset_path, offsets, {'group': group, 'total_processed': total_processed})


def _write_revenue(processed_events_path):
    agg = defaultdict(lambda: [0, 0.0])
    with processed_events_path.open('r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                e = json.loads(line)
                if e.get('score') is not None:
                    agg[e['region']][0] += 1
                agg[e['region']][1] += float(e['revenue'])
    with OUT_REVENUE.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['region', 'txn_count', 'revenue_total', 'revenue_mean'])
        for region in sorted(agg):
            n, total = agg[region]
            w.writerow([region, n, f'{total:.2f}', f'{total/n:.12f}'])


def consume_group(name: str, worker, mode: str):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    offset_path, processed_path = _paths(name)
    committed = load_committed_offsets(offset_path, PARTITIONS)
    processed_ids = load_processed_ids(processed_path)
    before_ids = len(processed_ids)
    attempted = duplicates = 0
    new_events = 0
    t0 = time.perf_counter()

    with processed_path.open('a', encoding='utf-8') as ledger:
        for event in _eligible_events(name):
            attempted += 1
            eid = int(event['event_id'])
            if eid in processed_ids:
                duplicates += 1
            else:
                worker(event)
                ledger.write(f'{eid}\n')
                processed_ids.add(eid)
                new_events += 1

            p = int(event['partition'])
            committed[p] = max(committed.get(p, 0), int(event['offset']) + 1)
            if attempted % COMMIT_EVERY == 0:
                ledger.flush()
                _write_commit(name, committed, len(processed_ids))
        ledger.flush()

    _write_commit(name, committed, len(processed_ids))
    seconds = time.perf_counter() - t0
    total_events = count_log()
    ends = partition_end_offsets()
    final_lag = sum(max(0, ends.get(p, -1) + 1 - committed.get(p, 0)) for p in range(PARTITIONS))
    return {
        'group': name, 'processed': new_events, 'total_processed': len(processed_ids),
        'attempted': attempted, 'duplicates_skipped': duplicates, 'seconds': seconds,
        'events_per_sec': new_events / seconds if seconds else 0,
        'final_lag': final_lag, 'committed': committed, 'end_offsets': ends, 'prior_processed': before_ids,
    }


def main() -> int:
    banner('CONSUMERS — independent groups, committed offsets, at-least-once delivery, idempotent effects')
    if count_log() == 0:
        raise SystemExit('Run producer.py first.')
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    revenue_events_path = STATE_DIR / 'revenue_projector_events.jsonl'
    # Producer resets state. Keep writers open for the complete group run for realistic I/O.
    with revenue_events_path.open('a', encoding='utf-8') as revenue_file, \
         OUT_AUDIT.open('a', encoding='utf-8') as audit_file, \
         OUT_ALERTS.open('a', newline='', encoding='utf-8') as alert_file:
        # Ensure alert header exists on an empty/new file.
        if alert_file.tell() == 0:
            csv.writer(alert_file).writerow(['event_id', 'region', 'score', 'threshold', 'severity'])

        def revenue_worker(e):
            revenue_file.write(json.dumps(e, separators=(',', ':')) + '\n')
        def audit_worker(e):
            audit_file.write(json.dumps({'event_id': e['event_id'], 'region': e['region'], 'score': e['score'], 'group': 'audit-writer'}, separators=(',', ':')) + '\n')
        def alert_worker(e):
            if e.get('score') is not None and e['score'] >= 90:
                csv.writer(alert_file).writerow([e['event_id'], e['region'], e['score'], 90, 'HIGH'])

        results = []
        for group, worker, mode in [
            ('revenue-projector', revenue_worker, 'revenue'),
            ('audit-writer', audit_worker, 'audit'),
            ('high-value-alerter', alert_worker, 'alert'),
        ]:
            result = consume_group(group, worker, mode)
            results.append(result)
            print(f"{group:20} processed {result['processed']:,} new / {result['total_processed']:,} total; duplicates {result['duplicates_skipped']:,}; lag {result['final_lag']:,}; throughput {result['events_per_sec']:,.0f}/s")

    _write_revenue(revenue_events_path)
    with OUT_LAG.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['group','processed','total_processed','attempted','seconds','events_per_sec','duplicates_skipped','final_lag'])
        for r in results:
            w.writerow([r['group'], r['processed'], r['total_processed'], r['attempted'], f"{r['seconds']:.6f}", f"{r['events_per_sec']:.2f}", r['duplicates_skipped'], r['final_lag']])

    with (RESULTS_DIR / 'consumer_offsets.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerow(['group','partition','end_offset','committed_offset','lag'])
        for r in results:
            for p in range(PARTITIONS):
                end = r['end_offsets'].get(p, -1); committed = r['committed'].get(p, 0)
                w.writerow([r['group'], p, end, committed, max(0, end + 1 - committed)])

    # Explicit idempotency evidence: re-present the most recent commit-sized window without
    # changing offsets and verify that every event is already in the group's event-id ledger.
    latest = list(read_events())[-COMMIT_EVERY:]
    idem = []
    for group in GROUPS:
        ids = load_processed_ids(_paths(group)[1])
        duplicates = sum(1 for e in latest if int(e['event_id']) in ids)
        idem.append({'group': group, 'test_window_events': len(latest), 'duplicate_deliveries_detected': duplicates, 'would_apply_side_effects': max(0, len(latest) - duplicates), 'idempotent': duplicates == len(latest)})
    write_json(RESULTS_DIR / 'consumer_idempotency_test.json', {'window_size': len(latest), 'groups': idem, 'method': 're-present the last committed batch against each group event-id ledger'})
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
