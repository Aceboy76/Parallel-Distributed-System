import csv
from pathlib import Path

from config import *
from common import write_json


def read_csv(path):
    with path.open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def main() -> int:
    banner('RECONCILIATION — Session 2 stream vs Session 1 batch baseline')
    if not OUT_REVENUE.exists():
        raise SystemExit('Run consumers.py first.')
    session1_baseline = SESSION1_DIR / 'results' / 'baseline_result.csv'
    if not session1_baseline.exists():
        raise SystemExit(f'Missing Session 1 baseline: {session1_baseline}')

    batch = {r['region']: r for r in read_csv(session1_baseline)}
    stream = {r['region']: r for r in read_csv(OUT_REVENUE)}
    groups_identical = set(batch) == set(stream)
    regions = sorted(set(batch) | set(stream))
    max_count = 0
    max_total = 0.0
    max_mean = 0.0
    count_diffs = {}
    total_diffs = {}
    mean_diffs = {}
    for region in regions:
        b = batch.get(region, {'txn_count': 0, 'score_total': 0, 'score_mean': 0})
        s = stream.get(region, {'txn_count': 0, 'revenue_total': 0, 'revenue_mean': 0})
        cd = abs(int(b['txn_count']) - int(s['txn_count']))
        td = abs(float(b['score_total']) - float(s['revenue_total']))
        md = abs(float(b['score_mean']) - float(s['revenue_mean']))
        count_diffs[region] = cd
        total_diffs[region] = td
        mean_diffs[region] = md
        max_count = max(max_count, cd)
        max_total = max(max_total, td)
        max_mean = max(max_mean, md)

    batch_total = sum(float(r['score_total']) for r in batch.values())
    stream_total = sum(float(r['revenue_total']) for r in stream.values())
    passed = groups_identical and max_count == 0 and max_total == 0.0 and max_mean <= TOLERANCE

    report = {
        'passed': passed,
        'regions': len(batch),
        'transactions_batch': sum(int(r['txn_count']) for r in batch.values()),
        'transactions': sum(int(r['txn_count']) for r in batch.values()),
        'transactions_stream': sum(int(r['txn_count']) for r in stream.values()),
        'group_sets_identical': groups_identical,
        'max_count_difference': max_count,
        'count_difference': max_count,
        'max_total_difference': max_total,
        'max_mean_difference': max_mean,
        'maximum_mean_difference': max_mean,
        'aggregate_batch': batch_total,
        'aggregate_stream': stream_total,
        'aggregate_difference': abs(batch_total - stream_total),
        'tolerance': TOLERANCE,
        'ci_condition': 'group sets identical AND max count difference == 0 AND max total difference == 0 AND max mean difference <= tolerance',
        'evidence_source': str(session1_baseline),
    }
    write_json(OUT_RECON, report)
    print(f'group sets identical : {groups_identical}')
    print(f'transactions batch   : {report["transactions_batch"]:,}')
    print(f'transactions stream  : {report["transactions_stream"]:,}')
    print(f'max count difference : {max_count}')
    print(f'max total difference : {max_total:.12g}')
    print(f'max mean difference  : {max_mean:.12g}')
    print(f'tolerance             : {TOLERANCE}')
    print(f'result                : {"PASSED" if passed else "FAILED"}')
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
